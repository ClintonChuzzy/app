# The Degens – Android app

Native Android app (Kotlin + Jetpack Compose) built from the "Product Landing Page" Figma file.

## Run it
1. Install **Android Studio** (current stable release).
2. **File > Open** and choose this `TheDegens` folder. Let Gradle sync (it downloads Gradle 8.9 and the libraries; needs internet).
   If Android Studio offers to update the Android Gradle Plugin or Kotlin versions, accepting is fine.
3. Pick an emulator or a USB-connected phone and press **Run**.

Requirements: Android 8.0 (API 26) or newer.

## What's in it
- One scrolling screen with the same sections as the design: hero, "Why choose us" cards, Drag & Drop, Team
  management, Email & SMS broadcast, Portfolio, call to action and footer.
- Top bar with a menu that scrolls to each section, and a scroll-progress bar.
- Effects: sections fade up as they scroll in, hero artwork floats, buttons shrink when pressed, and the Team
  timeline is clickable (the progress bar animates to the step you tap).
- All images are in `res/drawable-nodpi`, and all icons were converted from the Figma vectors into
  Android vector drawables in `res/drawable`.

## Code map (`app/src/main/java/com/thedegens/app`)
- `MainActivity.kt` – activity, colors, shared effects/buttons, top bar, scroll handling
- `Sections.kt` – every screen section

## Things to finish
- **Fonts:** the design uses Playfair Display (headings) and Satoshi (body). They aren't bundled, so the app uses
  the system serif/sans. To match the design, put the `.ttf` files in `res/font/` and set `HeadingFont` / `BodyFont`
  in `MainActivity.kt`, e.g. `FontFamily(Font(R.font.playfair_display_bold, FontWeight.Bold))`.
- **Buttons:** "Play Demo", "Learn More" and "Get The Degens App" have empty click handlers. Add your actions.
- **Text:** placeholder text from the design is kept as-is (including "Appoinments", "Managment", "togather").
