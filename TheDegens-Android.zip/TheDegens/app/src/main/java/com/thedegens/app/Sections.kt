package com.thedegens.app

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SectionPad = 24.dp
private val SectionGap = 80.dp

/* ============================== HERO ============================== */

@Composable
fun Hero(onFindOut: () -> Unit) {
    Column(Modifier.reveal().padding(horizontal = SectionPad).padding(top = 24.dp)) {
        Text(
            "Build your\nNext Product\nwith Degens.",
            color = Color.White, fontFamily = HeadingFont, fontWeight = FontWeight.Bold,
            fontSize = 46.sp, lineHeight = 54.sp
        )
        Spacer(Modifier.height(18.dp))
        Body("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.")
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            PrimaryButton("Find out more", onFindOut)
            Spacer(Modifier.width(20.dp))
            PlayDemo()
        }
        Spacer(Modifier.height(36.dp))
        HeroArt()
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun PlayDemo() {
    Row(Modifier.bounceClick { }, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(C.Pink), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(16.dp)) {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(size.width * 0.2f, 0f); lineTo(size.width, size.height / 2); lineTo(size.width * 0.2f, size.height); close()
                }
                drawPath(path, Color.White)
            }
        }
        Spacer(Modifier.width(12.dp))
        Text("Play Demo", color = Color(0xFF8A8F9A), fontFamily = BodyFont, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}

/** Hero artwork, positioned in % of the 979 x 966 Figma stage. */
@Composable
private fun HeroArt() {
    val transition = rememberInfiniteTransition(label = "float")
    val dy by transition.animateFloat(
        initialValue = 0f, targetValue = -14f,
        animationSpec = infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dy"
    )
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(979f / 966f)) {
        val w = maxWidth
        val h = maxHeight
        Canvas(Modifier.offset(0.dp, h * 0.583f).size(w * 0.708f)) {
            drawCircle(Brush.verticalGradient(0f to Color(0xFFFFB74A), 0.65f to C.Pink, 1f to C.Pink))
        }
        Image(
            painterResource(R.drawable.hero_card), null,
            Modifier.offset(w * 0.065f, h * 0.183f).width(w * 0.782f)
        )
        Image(
            painterResource(R.drawable.hero_phone), null,
            Modifier.offset(w * 0.679f, h * 0.206f).width(w * 0.321f)
                .graphicsLayer { translationY = dy.dp.toPx() * 1.6f }
        )
        Image(
            painterResource(R.drawable.orb), null,
            Modifier.offset(w * 0.80f, h * 0.03f).width(w * 0.13f)
                .graphicsLayer { translationY = -dy.dp.toPx() }
        )
    }
}

/* ============================ WHY CHOOSE US ============================ */

@Composable
fun Why() {
    Column(Modifier.reveal().padding(top = SectionGap)) {
        Box(Modifier.padding(horizontal = SectionPad)) { H2("Check why you Should Choose us", TextAlign.Center) }
        Spacer(Modifier.height(36.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = SectionPad),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item { FeatureCard("Appoinments", "Built Wicket longer admire do barton vanity itself do in it.", R.drawable.satellite, false) }
            item { FeatureCard("Fast Support", "Engrossed listening. Park gate sell they west hard for the.", R.drawable.feature_support, true) }
            item { FeatureCard("App Integrations", "Barton vanity itself do in it. Preferd to men it engrossed listening.", R.drawable.feature_ui, false) }
            item { FeatureCard("Customization", "We deliver outsourced aviation services for military customers", R.drawable.power_supply, false) }
        }
    }
}

@Composable
private fun FeatureCard(title: String, text: String, icon: Int, active: Boolean) {
    Box(Modifier.width(264.dp).padding(bottom = 20.dp)) {
        if (active) {
            Box(
                Modifier.align(Alignment.BottomStart).offset((-12).dp, 20.dp).size(84.dp)
                    .background(C.Pink, RoundedCornerShape(6.dp))
            )
        }
        Column(
            Modifier.fillMaxWidth().height(318.dp).glass(34.dp).padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(112.dp, 92.dp)) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(56.dp, 54.dp)
                        .background(C.Pink.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                )
                Image(painterResource(icon), null, Modifier.align(Alignment.TopStart).size(76.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text(title, color = Color.White, fontFamily = BodyFont, fontWeight = FontWeight.Bold, fontSize = 23.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Body(text, color = C.Muted, align = TextAlign.Center, size = 15)
        }
    }
}

/* ============================= DRAG & DROP ============================= */

@Composable
fun DragDrop() {
    Column(Modifier.reveal().padding(horizontal = SectionPad).padding(top = SectionGap)) {
        Eyebrow("DRAG & DROP")
        Spacer(Modifier.height(8.dp))
        H2("Control all elements super easy.")
        Spacer(Modifier.height(28.dp))
        Feature(R.drawable.ico_drag, "Drag Image & SVG", "Create beautiful sites at breakneck speed without compromising on your creativity.")
        Spacer(Modifier.height(22.dp))
        Feature(R.drawable.ico_field, "Create Custom Field", "Keep your brand front & center with your customer")
        Spacer(Modifier.height(22.dp))
        Feature(R.drawable.ico_attr, "Custom Attribute", "Increase your client retention rate by showing your results and value.")
        Spacer(Modifier.height(32.dp))
        Image(
            painterResource(R.drawable.dragdrop_calendar), "Calendar app interface",
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
        )
    }
}

@Composable
private fun Feature(icon: Int, title: String, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Image(painterResource(icon), null, Modifier.padding(top = 5.dp).size(28.dp))
        Spacer(Modifier.width(18.dp))
        Column {
            Text(title, color = Color.White, fontFamily = BodyFont, fontWeight = FontWeight.Medium, fontSize = 20.sp)
            Body(text, color = C.Muted, size = 15)
        }
    }
}

/* ============================ TEAM MANAGEMENT ============================ */

@Composable
fun Team() {
    val steps = listOf("Create task for any team person", "Make timeframe for do the task", "Get task complated by your member")
    val targets = listOf(0.304f, 0.65f, 1f)
    var step by remember { mutableIntStateOf(0) }
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val fill by animateFloatAsState(if (started) targets[step] else 0f, tween(900, easing = FastOutSlowInEasing), label = "progress")

    Column(Modifier.reveal().padding(horizontal = SectionPad).padding(top = SectionGap)) {
        H2("Bring all Team Managment & task togather", TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Body(
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
            align = TextAlign.Center, size = 15
        )
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x1FFFFFFF))) {
            Box(Modifier.fillMaxWidth(fill).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(C.Amber))
        }
        Spacer(Modifier.height(14.dp))
        steps.forEachIndexed { i, label ->
            Row(
                Modifier.fillMaxWidth().clickable { step = i }.padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StepDot(done = i <= step)
                Spacer(Modifier.width(16.dp))
                Text(label, color = Color.White.copy(alpha = if (i <= step) 1f else 0.7f), fontFamily = BodyFont, fontWeight = FontWeight.Medium, fontSize = 18.sp)
            }
        }
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().glass(30.dp).padding(12.dp)) {
            Image(
                painterResource(R.drawable.team_dashboard), "Team management dashboard",
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            )
        }
    }
}

@Composable
private fun StepDot(done: Boolean) {
    Box(
        Modifier.size(22.dp).clip(CircleShape)
            .then(if (done) Modifier.background(Color(0x1FFFFFFF)) else Modifier.border(1.dp, Color.White, CircleShape)),
        contentAlignment = Alignment.Center
    ) {
        if (done) Box(Modifier.size(12.dp).clip(CircleShape).background(C.Pink))
    }
}

/* ============================ EMAIL & SMS BROADCAST ============================ */

@Composable
fun Broadcast() {
    Column(Modifier.reveal().padding(horizontal = SectionPad).padding(top = SectionGap)) {
        Eyebrow("EMAIL & SMS BROADCAST")
        Spacer(Modifier.height(8.dp))
        H2("We have email, sms Broadcast for you.")
        Spacer(Modifier.height(16.dp))
        Body("Broadcast and email is best use for something announcing significant changes .")
        Spacer(Modifier.height(24.dp))
        CheckItem("Makes them purchase your product, service and quis interact website due.")
        CheckItem("Holds and catches their attention lorem.")
        CheckItem("Diverts them to your brand.")
        Spacer(Modifier.height(26.dp))
        OutlineButton("Learn More") { }
        Spacer(Modifier.height(36.dp))
        Box(Modifier.fillMaxWidth()) {
            Image(
                painterResource(R.drawable.broadcast_site), "Website builder preview",
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            )
            Image(
                painterResource(R.drawable.broadcast_grid), "Grid layout panel",
                Modifier.align(Alignment.BottomEnd).offset(8.dp, 28.dp).width(128.dp).clip(RoundedCornerShape(14.dp))
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CheckItem(text: String) {
    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Image(painterResource(R.drawable.check), null, Modifier.padding(top = 6.dp).size(20.dp, 18.dp))
        Spacer(Modifier.width(14.dp))
        Body(text, color = C.Muted, size = 15)
    }
}

/* ================================ PORTFOLIO ================================ */

@Composable
fun Works() {
    val works = listOf(R.drawable.work_1, R.drawable.work_2, R.drawable.work_3, R.drawable.work_4)
    Column(Modifier.reveal().padding(top = SectionGap)) {
        Column(Modifier.padding(horizontal = SectionPad)) {
            Eyebrow("Our Works")
            Spacer(Modifier.height(6.dp))
            H2("Our Portfolio")
        }
        Spacer(Modifier.height(28.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = SectionPad),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(works.size) { i ->
                Image(
                    painterResource(works[i]), null,
                    Modifier.width(264.dp).aspectRatio(455f / 581f).clip(RoundedCornerShape(26.dp)),
                    contentScale = ContentScale.Crop,
                    alignment = if (i % 2 == 0) Alignment.CenterStart else Alignment.Center
                )
            }
        }
    }
}

/* ============================== CALL TO ACTION ============================== */

@Composable
fun Cta() {
    Column(
        Modifier.reveal().fillMaxWidth().padding(horizontal = SectionPad).padding(top = SectionGap),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.deco_dots), null, Modifier.size(60.dp, 52.dp))
        Spacer(Modifier.height(12.dp))
        H2("Try Degens Free", TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Body("After your 14-day trial of our Professional plan, enjoy the Free version of Calendly – forever.", align = TextAlign.Center, size = 15)
        Spacer(Modifier.height(30.dp))
        OutlineButton("Get The Degens App") { }
        Spacer(Modifier.height(18.dp))
        Text("No Credit Card Required. Cancel Anytime", color = Color.White.copy(alpha = 0.6f), fontFamily = BodyFont, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

/* ================================== FOOTER ================================== */

@Composable
fun Footer() {
    Box(Modifier.padding(top = SectionGap).fillMaxWidth()) {
        Image(painterResource(R.drawable.footer_mountains), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(C.Navy, C.Navy.copy(alpha = 0.84f)))))
        Column(
            Modifier.fillMaxWidth().padding(horizontal = SectionPad).padding(top = 48.dp, bottom = 28.dp).navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo_mark), null, Modifier.size(32.dp, 36.dp))
                Spacer(Modifier.width(12.dp))
                Text("THE DEGENS", color = Color.White, fontFamily = BodyFont, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            }
            Spacer(Modifier.height(30.dp))
            Text("Find us on Social Media", color = Color.White, fontFamily = BodyFont, fontWeight = FontWeight.Medium, fontSize = 18.sp)
            Spacer(Modifier.height(16.dp))
            Image(painterResource(R.drawable.socmed), "Discord, Twitter, Instagram, YouTube", Modifier.width(200.dp))
            Spacer(Modifier.height(30.dp))
            Text("We’r always happy to help.", color = Color.White, fontFamily = BodyFont, fontWeight = FontWeight.Medium, fontSize = 18.sp)
            Text("ContectThedegens@gmail.com", color = C.Muted, fontFamily = BodyFont, fontSize = 16.sp)
            Spacer(Modifier.height(30.dp))
            Text("© 2022 . all Right Reserved", color = Color.White.copy(alpha = 0.8f), fontFamily = BodyFont, fontSize = 13.sp)
        }
    }
}
