package com.thedegens.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DegensApp() }
    }
}

/** Design tokens taken from the Figma file. */
object C {
    val Navy = Color(0xFF0E102C)
    val Pink = Color(0xFFFF3969)
    val Amber = Color(0xFFFFB64B)
    val Muted = Color(0xFFA6A6A6)
    val Label = Color(0xFF939393)
    val Glass = Color(0x0FFFFFFF)
    val Border = Color(0x24FFFFFF)
}

// Playfair Display / Satoshi are not bundled; drop the .ttf files in res/font and swap these (see README).
val HeadingFont = FontFamily.Serif
val BodyFont = FontFamily.SansSerif

/* ---------------- Effects & small building blocks ---------------- */

fun Modifier.glass(radius: Dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this.clip(shape).background(C.Glass).border(1.dp, C.Border, shape)
}

/** Fade + slide up the first time a section scrolls into view. */
@Composable
fun Modifier.reveal(): Modifier {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
    return this.graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 36.dp.toPx()
    }
}

/** Click that shrinks slightly while pressed. */
@Composable
fun Modifier.bounceClick(onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, label = "press")
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

@Composable
fun H2(text: String, align: TextAlign = TextAlign.Start) = Text(
    text, modifier = Modifier.fillMaxWidth(), color = Color.White, fontFamily = HeadingFont,
    fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 42.sp, textAlign = align
)

@Composable
fun Eyebrow(text: String) = Text(text, color = C.Label, fontFamily = BodyFont, fontSize = 15.sp, fontWeight = FontWeight.Medium)

@Composable
fun Body(text: String, color: Color = Color.White, align: TextAlign = TextAlign.Start, size: Int = 16) = Text(
    text, modifier = Modifier.fillMaxWidth(), color = color, fontFamily = BodyFont,
    fontSize = size.sp, lineHeight = (size * 1.7f).sp, textAlign = align
)

@Composable
fun PrimaryButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .shadow(14.dp, shape, ambientColor = C.Pink, spotColor = C.Pink)
            .bounceClick(onClick)
            .clip(shape)
            .background(C.Pink)
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) { Text(label, color = Color.White, fontFamily = BodyFont, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun OutlineButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .bounceClick(onClick)
            .clip(shape)
            .border(1.dp, Color.White, shape)
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) { Text(label, color = Color.White, fontFamily = BodyFont, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
}

/* ---------------- App shell ---------------- */

@Composable
fun DegensApp() {
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    // Scroll progress for the bar under the top bar
    val progress by remember {
        derivedStateOf {
            val total = list.layoutInfo.totalItemsCount.coerceAtLeast(1)
            val first = list.layoutInfo.visibleItemsInfo.firstOrNull()
            val part = if (first != null && first.size > 0) list.firstVisibleItemScrollOffset / first.size.toFloat() else 0f
            ((list.firstVisibleItemIndex + part) / total).coerceIn(0f, 1f)
        }
    }
    fun goTo(index: Int) {
        menuOpen = false
        scope.launch { list.animateScrollToItem(index) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(C.Navy)
            .drawBehind {
                // soft pink glows from the Figma background ellipses
                drawRect(Brush.radialGradient(listOf(C.Pink.copy(alpha = 0.30f), Color.Transparent),
                    center = Offset(size.width * 0.9f, size.height * 0.12f), radius = size.width * 0.9f))
                drawRect(Brush.radialGradient(listOf(C.Pink.copy(alpha = 0.18f), Color.Transparent),
                    center = Offset(0f, size.height * 0.75f), radius = size.width))
            }
    ) {
        LazyColumn(state = list, contentPadding = PaddingValues(top = topInset + 67.dp)) {
            item { Hero(onFindOut = { goTo(1) }) }
            item { Why() }
            item { DragDrop() }
            item { Team() }
            item { Broadcast() }
            item { Works() }
            item { Cta() }
            item { Footer() }
        }
        Box(Modifier.align(Alignment.TopCenter)) {
            TopBar(open = menuOpen, onToggle = { menuOpen = !menuOpen }, onNav = ::goTo, progress = progress)
        }
    }
}

@Composable
fun TopBar(open: Boolean, onToggle: () -> Unit, onNav: (Int) -> Unit, progress: Float) {
    val links = listOf("Home" to 0, "About" to 1, "Get Wassified" to 2, "Rewards" to 3, "Roadmap" to 4, "Team" to 5)
    Column(
        Modifier
            .fillMaxWidth()
            .background(C.Navy.copy(alpha = 0.94f))
            .statusBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().height(64.dp).padding(start = 20.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(painterResource(R.drawable.logo_mark), contentDescription = null, modifier = Modifier.size(32.dp, 36.dp))
            Spacer(Modifier.width(12.dp))
            Text("THE DEGENS", color = Color.White, fontFamily = BodyFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onToggle) {
                Icon(if (open) Icons.Filled.Close else Icons.Filled.Menu, contentDescription = if (open) "Close menu" else "Open menu", tint = Color.White)
            }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            Box(
                Modifier.fillMaxWidth(progress).fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(C.Amber, C.Pink)))
            )
        }
        AnimatedVisibility(visible = open, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                links.forEach { (name, index) ->
                    Text(
                        name, color = Color.White, fontFamily = BodyFont, fontSize = 20.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onNav(index) }.padding(vertical = 14.dp)
                    )
                }
            }
        }
    }
}
